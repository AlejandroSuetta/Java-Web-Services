/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webServices;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Suetta
 */
@WebService(serviceName = "holaEduIt")
public class NewWebService {
    @WebMethod(operationName = "saludo")
    public String hola(@WebParam(name = "texo")String texto) {
        return texto + ", saludos de EducacionIT";
    }
}
