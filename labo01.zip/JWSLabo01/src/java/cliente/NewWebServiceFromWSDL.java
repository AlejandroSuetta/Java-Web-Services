/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import javax.jws.WebService;

/**
 *
 * @author Suetta
 */
@WebService(serviceName = "holaEduIt", portName = "NewWebServicePort", endpointInterface = "webservices.NewWebService", targetNamespace = "http://webServices/", wsdlLocation = "WEB-INF/wsdl/NewWebServiceFromWSDL/localhost_8080/JWSLabo01/holaEduIt.wsdl")
public class NewWebServiceFromWSDL {

    public java.lang.String saludo(java.lang.String texo) {
        //TODO implement this method
        throw new UnsupportedOperationException("Not implemented yet.");
    }
    
}
